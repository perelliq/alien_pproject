import os

import pygame

from itertools import product


class Board:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        self.left = 50
        self.top = 50
        self.cell_size = 50

    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self, surface):
        for x, y in product(range(self.width), range(self.height)):
            pygame.draw.rect(surface, 'white',
                             (self.left + self.cell_size * x, self.top + self.cell_size * y,
                              self.cell_size, self.cell_size), width=1, )


DISPLAY_SIZE = (640, 480)
pygame.init()
screen = pygame.display.set_mode(DISPLAY_SIZE)

board = Board(5, 7)
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.fill((0, 0, 0))
    board.render(screen)
    pygame.display.flip()

pygame.image.save(screen, os.path.join('static', 'save_image_1.BMP'))
print("save image_1")

pygame.quit()
